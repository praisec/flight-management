package edu.westga.cs1301.flight_management.model;

import java.util.ArrayList;

/** Manage the passengers and plane for a Flight
 * 
 * @author CS1301
 * @version Spring 2017
 */

		
public class Flight {
	public static final int FIRST_CLASS_SEAT_TYPE = 11;
	public static final int COACH_SEAT_TYPE = 22;
	
	private ArrayList <Passenger> firstClassPassengers;
	private ArrayList <Passenger> coachPassengers;
	private Plane plane;

	public void setPlane(Plane plane) {
		this.plane = plane;
	}
	public ArrayList<Passenger> getCoachPassengers() {
		return coachPassengers;
	}

	
	public ArrayList<Passenger> getFirstClassPassengers(){
		return firstClassPassengers;
	}
	
	
	
	public Plane getPlane() {
		return this.plane;
	}
	
	
	
	/** Create a new flight with the given Plane and no passengers (first class or coach).
	 * 
	 * @precondition plane != null
	 * @postcondition getPlane() == plane &&
	 * 				  getFirstClassPassengers().size() == 0 &&
	 * 				  getCoachPassengers().size() == 0
	 * 
	 * @param plane the plane for this Flight
	 */
	public Flight(Plane plane) {
		if (plane == null)  {
			throw new IllegalArgumentException ("plane is invalid");
		}
		
		this.plane = plane;
		this.firstClassPassengers = new ArrayList <Passenger> ();
		this.coachPassengers = new ArrayList <Passenger> ();
		
	}
	
	/** Add a new passenger to the flight with the specified seat type.
	 * The passenger is not added if there is no space left in the 
	 * appropriate section.
	 * 
	 * @precondition passenger != null &&
	 * 				 (requestedSeatType == Flight.COACH_SEAT_TYPE || requestedSeatType == Flight.FIRST_CLASS_SEAT_TYPE)
	 * @postcondition getFirstClassPassengers().size() == getFirstClassPassengers().size()@pre+1 if requestedSeatType == Flight.FIRST_CLASS_SEAT_TYPE || 
	 * 				  getCoachPassengers().size() == getCoachPassengers().size()@pre+1 if requestedSeatType == Flight.COACH_SEAT_TYPE
	 * 
	 * @param passenger the passenger to add to the flight
	 * @param requestedSeatType the type of seat requested (either Flight.COACH_SEAT_TYPE or Flight.FIRST_CLASS_SEAT_TYPE)
	 * 
	 * @return true if passenger was added;
	 * 		   false if passenger was not added;
	 */
	public boolean addPassenger(Passenger passenger, int requestedSeatType) {
		if (passenger == null){
			throw new IllegalArgumentException ("passenger cannot be null");
		}
		 if (requestedSeatType != Flight.COACH_SEAT_TYPE && requestedSeatType != Flight.FIRST_CLASS_SEAT_TYPE){
				throw new IllegalArgumentException ("passenger is invalid");
		 }
		 
		 if (requestedSeatType == Flight.FIRST_CLASS_SEAT_TYPE &&
				 firstClassPassengers.size() < this.plane.getFirstClassCapacity()){
			 this.firstClassPassengers.add(passenger);
			 
			 return true;
		 }
			 
		  
		 if (requestedSeatType == Flight.COACH_SEAT_TYPE && 
				 coachPassengers.size() < this.plane.getCoachCapacity()){
			 this.coachPassengers.add(passenger);
			 
			 return true;
		 } 
		 return false;
		 
		 
	}
	
	/** Check if the specified passenger is either a 
	 * first class or coach passenger for this Flight.
	 * 
	 * @precondition passenger != null
	 * @postcondition none
	 * 
	 * @param passenger
	 * @return true iff the passenger is in either the first class or coach passenger collections.
	 */
	public boolean containsPassenger(Passenger passenger) {
		if (passenger ==null)
			throw new IllegalArgumentException ("pasenger cannot be null");
		 
		for (Passenger currentPassenger : this.coachPassengers){
			 if (currentPassenger.getName() == passenger.getName() && currentPassenger.getRewardsId() == passenger.getRewardsId()){
				 
				 return true;
			 }
				
		 }
			 
		for (Passenger currentPassengers : this.firstClassPassengers){
			if (currentPassengers.getName() == passenger.getName() && currentPassengers.getRewardsId() == passenger.getRewardsId()){
				 
				 return true;
			 }				
 }	
		return false;
	
	}
	
	
	/** Upgrade the passenger from coach to first class.
	 * 
	 * @precondition passenger != null
	 * @postcondition getFirstClassPassengers().size() == getFirstClassPassengers().size()@pre+1 if requestedSeatType == Flight.FIRST_CLASS_SEAT_TYPE && 
	 * 				  getCoachPassengers().size() == getCoachPassengers().size()@pre-1 if requestedSeatType == Flight.COACH_SEAT_TYPE
	 * 
	 * @param passenger the passenger to be upgraded
	 * 
	 * @return true if the passenger was upgraded;
	 * 		   false if the passenger was not upgraded
	 */
	public boolean upgradePassenger(Passenger passenger) {
if (passenger == null){
	throw new IllegalArgumentException ("passenger cannot be null");
}

for (Passenger currentPassenger : this.coachPassengers){
	 if (currentPassenger.getName() == passenger.getName() && currentPassenger.getRewardsId() == passenger.getRewardsId() 
			 && firstClassPassengers.size() < plane.getFirstClassCapacity()) {
		 coachPassengers.remove(currentPassenger);
		 firstClassPassengers.add(currentPassenger);
	 
		 return true;
	 }
		
}
return false;
	}
	
}
