package edu.westga.cs1301.flight_management.model;

/** Stores information for a specific Passenger
 * 
 * @author CS1301
 * @version Spring 2017
 */
public class Passenger {
	private String name;
	private int rewardsId;
	
	/** Create a new Passenger with the specified name and rewards id.
	 * 
	 * @precondition name != null && !name.isEmpty()
	 * @postcondition getName() == name &&
	 * 				  getRewardsId() == rewardsId
	 * 
	 * @param name
	 * @param rewardsId
	 */
	public Passenger(String name, int rewardsId) {
		if(name == null || name.isEmpty()) {
			throw new IllegalArgumentException("A valid name must be provided");
		}
		this.name = name;
		this.rewardsId = rewardsId;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getRewardsId() {
		return this.rewardsId;
	}

}
