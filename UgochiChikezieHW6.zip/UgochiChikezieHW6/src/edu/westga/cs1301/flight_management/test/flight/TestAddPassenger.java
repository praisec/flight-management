package edu.westga.cs1301.flight_management.test.flight;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Flight;
import edu.westga.cs1301.flight_management.model.Passenger;
import edu.westga.cs1301.flight_management.model.Plane;

public class TestAddPassenger {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testNullPassenger() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		
		this.expected.expect(IllegalArgumentException.class);
		flight.addPassenger(null, Flight.COACH_SEAT_TYPE);
	}
	
	@Test
	public void testInvalidSeatType() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger = new Passenger("James", 0);
		
		this.expected.expect(IllegalArgumentException.class);
		flight.addPassenger(passenger, 0);
	}
	
	@Test
	public void testAddFirstCoachPassenger() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger = new Passenger("James", 0);
		
		boolean result = flight.addPassenger(passenger, Flight.COACH_SEAT_TYPE);
		
		assertEquals("Checking number of coach passengers", 1, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger rewards id", 0, flight.getCoachPassengers().get(0).getRewardsId());
		assertTrue("Checking result", result);
	}
	
	@Test
	public void testAddSecondCoachPassenger() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Anastasia", 1);

		boolean result = flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		
		assertEquals("Checking number of coach passengers", 2, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger rewards id", 0, flight.getCoachPassengers().get(0).getRewardsId());
		assertEquals("Checking first coach passenger rewards id", 1, flight.getCoachPassengers().get(1).getRewardsId());
		assertTrue("Checking result", result);
	}
	
	@Test
	public void testAddThirdCoachPassengerWithMaximumOfTwoCoachPassengers() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Anastasia", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Elizabeth", 2);
		
		boolean result = flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		
		assertEquals("Checking number of coach passengers", 2, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger rewards id", 0, flight.getCoachPassengers().get(0).getRewardsId());
		assertEquals("Checking first coach passenger rewards id", 1, flight.getCoachPassengers().get(1).getRewardsId());
		assertFalse("Checking result", result);
	}
	
	@Test
	public void testAddFirstFirstClassPassenger() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger = new Passenger("James", 0);
		
		boolean result = flight.addPassenger(passenger, Flight.FIRST_CLASS_SEAT_TYPE);
		
		assertEquals("Checking number of first class passengers", 1, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertTrue("Checking result", result);
	}
	
	@Test
	public void testAddSecondFirstClassPassenger() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Anastasia", 1);

		boolean result = flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		
		assertEquals("Checking number of first class passengers", 2, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking second first class passenger rewards id", 1, flight.getFirstClassPassengers().get(1).getRewardsId());
		assertTrue("Checking result", result);
	}
	
	@Test
	public void testAddThirdFirstClassPassengerWithMaximumOfTwoFirstClassPassengers() {
		Plane plane = new Plane(2, 2);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Anastasia", 1);
		flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Elizabeth", 1);

		boolean result = flight.addPassenger(passenger3, Flight.FIRST_CLASS_SEAT_TYPE);
		
		assertEquals("Checking number of first class passengers", 2, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking second first class passenger rewards id", 1, flight.getFirstClassPassengers().get(1).getRewardsId());
		assertFalse("Checking result", result);
	}

}
