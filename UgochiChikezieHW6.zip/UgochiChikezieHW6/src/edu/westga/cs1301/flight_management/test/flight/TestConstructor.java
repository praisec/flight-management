package edu.westga.cs1301.flight_management.test.flight;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Flight;
import edu.westga.cs1301.flight_management.model.Plane;

public class TestConstructor {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testValid() {
		Plane plane = new Plane(0, 1);
		
		Flight result = new Flight(plane);
		
		assertSame("Checking plane", plane, result.getPlane());
		assertEquals("Checking number of first class passengers", 0, result.getFirstClassPassengers().size());
		assertEquals("Checking number of coach passengers", 0, result.getCoachPassengers().size());
	}
	
	@Test
	public void testNullPlane() {
		this.expected.expect(IllegalArgumentException.class);
		new Flight(null);
	}

}
