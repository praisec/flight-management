package edu.westga.cs1301.flight_management.test.flight;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Flight;
import edu.westga.cs1301.flight_management.model.Passenger;
import edu.westga.cs1301.flight_management.model.Plane;

public class TestContainsPassenger {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testNullPassenger() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		
		this.expected.expect(IllegalArgumentException.class);
		flight.containsPassenger(null);
	}
	
	@Test
	public void testNoPassengersAddedToFlight() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passenger1);

		assertFalse("Checking result", result);
	}
	
	@Test
	public void testContainsPassengerWithOneCoachPassenger() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsFirstCoachPassengerWithMultipleCoachPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsMiddleCoachPassengerWithMultipleCoachPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsLastCoachPassengerWithMultipleCoachPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsFirstFirstClassPassengerWithMultipleFirstClassPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsMiddleFirstClassPassengerWithMultipleFirstClassPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}
	
	@Test
	public void testContainsLastFirstClassPassengerWithMultipleFirstClassPassengers() {
		Plane plane = new Plane(3, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passengerToFind = new Passenger("James", 0);
		
		boolean result = flight.containsPassenger(passengerToFind);

		assertTrue("Checking result", result);
	}

}
