package edu.westga.cs1301.flight_management.test.flight;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Flight;
import edu.westga.cs1301.flight_management.model.Passenger;
import edu.westga.cs1301.flight_management.model.Plane;

public class TestUpgradePassenger {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testNullPassenger() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		
		this.expected.expect(IllegalArgumentException.class);
		flight.upgradePassenger(null);
	}
	
	@Test
	public void testUpgradePassengerWithNoCoachPassengers() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passenger1);

		assertFalse("Checking result", result);
		assertEquals("Checking number of first class passengers", 0, flight.getFirstClassPassengers().size());
		assertEquals("Checking number of coach passengers", 0, flight.getCoachPassengers().size());
	}
	
	@Test
	public void testUpgradePassengerWithOneCoachPassengerAndNoFirstClassPassengers() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passengerToUpgrade = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passengerToUpgrade);

		assertTrue("Checking result", result);
		assertEquals("Checking number of first class passengers", 1, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger's rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking number of coach passengers", 0, flight.getCoachPassengers().size());
	}
	
	@Test
	public void testUpgradeFirstCoachPassengerWithMultipleCoachPassengersAndNoFirstClassPassengers() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passengerToUpgrade = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passengerToUpgrade);

		assertTrue("Checking result", result);
		assertEquals("Checking number of first class passengers", 1, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger's rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking number of coach passengers", 2, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger's rewards id", 1, flight.getCoachPassengers().get(0).getRewardsId());
		assertEquals("Checking second coach passenger's rewards id", 2, flight.getCoachPassengers().get(1).getRewardsId());
	}
	
	@Test
	public void testUpgradeMiddleCoachPassengerWithMultipleCoachPassengersAndNoFirstClassPassengers() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passengerToUpgrade = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passengerToUpgrade);

		assertTrue("Checking result", result);
		assertEquals("Checking number of first class passengers", 1, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger's rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking number of coach passengers", 2, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger's rewards id", 1, flight.getCoachPassengers().get(0).getRewardsId());
		assertEquals("Checking second coach passenger's rewards id", 2, flight.getCoachPassengers().get(1).getRewardsId());
	}
	
	@Test
	public void testUpgradeLastCoachPassengerWithMultipleCoachPassengersAndNoFirstClassPassengers() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.COACH_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.COACH_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passengerToUpgrade = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passengerToUpgrade);
		
		assertTrue("Checking result", result);
		assertEquals("Checking number of first class passengers", 1, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger's rewards id", 0, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking number of coach passengers", 2, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger's rewards id", 1, flight.getCoachPassengers().get(0).getRewardsId());
		assertEquals("Checking second coach passenger's rewards id", 2, flight.getCoachPassengers().get(1).getRewardsId());
	}
	
	@Test
	public void testUpgradeCoachPassengerWithNoRemainingFirstClassSeats() {
		Plane plane = new Plane(2, 3);
		Flight flight = new Flight(plane);
		Passenger passenger2 = new Passenger("Elizabeth", 1);
		flight.addPassenger(passenger2, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger3 = new Passenger("Anastasia", 2);
		flight.addPassenger(passenger3, Flight.FIRST_CLASS_SEAT_TYPE);
		Passenger passenger1 = new Passenger("James", 0);
		flight.addPassenger(passenger1, Flight.COACH_SEAT_TYPE);
		Passenger passengerToUpgrade = new Passenger("James", 0);
		
		boolean result = flight.upgradePassenger(passengerToUpgrade);
		
		assertFalse("Checking result", result);
		assertEquals("Checking number of first class passengers", 2, flight.getFirstClassPassengers().size());
		assertEquals("Checking first first class passenger's rewards id", 1, flight.getFirstClassPassengers().get(0).getRewardsId());
		assertEquals("Checking second first class passenger's rewards id", 2, flight.getFirstClassPassengers().get(1).getRewardsId());
		assertEquals("Checking number of coach passengers", 1, flight.getCoachPassengers().size());
		assertEquals("Checking first coach passenger's rewards id", 0, flight.getCoachPassengers().get(0).getRewardsId());
	}

}
