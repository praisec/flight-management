package edu.westga.cs1301.flight_management.test.passenger;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Passenger;

public class TestConstructor {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testValid() {
		Passenger result = new Passenger("Elizabeth", 0);
		
		assertEquals("Checking name", "Elizabeth", result.getName());
		assertEquals("Checking rewards id", 0, result.getRewardsId());
	}

	@Test
	public void testNullName() {
		this.expected.expect(IllegalArgumentException.class);
		new Passenger(null, 0);
	}

	@Test
	public void testEmptyName() {
		this.expected.expect(IllegalArgumentException.class);
		new Passenger("", 0);
	}

}
