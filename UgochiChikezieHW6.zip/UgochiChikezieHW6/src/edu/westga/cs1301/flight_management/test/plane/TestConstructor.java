package edu.westga.cs1301.flight_management.test.plane;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.westga.cs1301.flight_management.model.Plane;

public class TestConstructor {
	
	@Rule public ExpectedException expected = ExpectedException.none();

	@Test
	public void testZeroFirstClassCapacityANDPositiveCoachCapacity() {
		Plane result = new Plane(0, 1);
		
		assertEquals("Checking first class capacity", 0, result.getFirstClassCapacity());
		assertEquals("Checking coach capacity", 1, result.getCoachCapacity());
	}
	@Test
	public void testPositiveFirstClassCapacityANDPositiveCoachCapacity() {
		Plane result = new Plane(1, 1);
		
		assertEquals("Checking first class capacity", 1, result.getFirstClassCapacity());
		assertEquals("Checking coach capacity", 1, result.getCoachCapacity());
	}

	@Test
	public void testNegativeFirstClassCapacity() {
		this.expected.expect(IllegalArgumentException.class);
		new Plane(-1, 1);
	}

	@Test
	public void testNegativeCoachCapacity() {
		this.expected.expect(IllegalArgumentException.class);
		new Plane(1, -1);
	}

	@Test
	public void testZeroCoachCapacity() {
		this.expected.expect(IllegalArgumentException.class);
		new Plane(0, 0);
	}

}
